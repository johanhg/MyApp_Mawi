class Dato < ApplicationRecord
end
